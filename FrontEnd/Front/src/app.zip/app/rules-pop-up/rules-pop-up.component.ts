import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rules-pop-up',
  templateUrl: './rules-pop-up.component.html',
  styleUrls: ['./rules-pop-up.component.css']
})
export class RulesPopUpComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
